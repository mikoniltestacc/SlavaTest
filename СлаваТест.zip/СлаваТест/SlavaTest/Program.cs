﻿using System;
using SlavaLibraryLib;

namespace SlavaTest
{
    // Точка входа в программу
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Создаём объект библиотеки — через него будем всё делать
            LibraryFunctions library = new LibraryFunctions();

            // 1. Показать название библиотеки
            Console.WriteLine("Название библиотеки");
            Console.WriteLine(library.GetLibraryName());
            Console.WriteLine(); // пустая строка-разделитель

            // 2. Показать главного библиотекаря
            Console.WriteLine("Главный библиотекарь");
            Console.WriteLine(library.GetChiefLibrarian());
            Console.WriteLine();

            // 3. Сменить главного на существующего сотрудника
            // "Петров П.С." есть в списке, поэтому смена пройдёт
            Console.WriteLine("Смена главного библиотекаря на сотрудника из списка");
            bool f = library.SetChiefLibrarian("Петров П.С.");
            Console.WriteLine("Изменено: " + f + ". Главный библиотекарь: " + library.GetChiefLibrarian());
            Console.WriteLine();

            // 4. Попробовать сменить на несуществующего
            // Сохраняем результат (true/false), чтобы показать его на экране
            Console.WriteLine("Попытка смены на несуществующего сотрудника");
            bool changed = library.SetChiefLibrarian("Несуществующий С.С.");
            Console.WriteLine("Изменено: " + changed + ". Главный библиотекарь: " + library.GetChiefLibrarian());
            Console.WriteLine();

            // 5. Сгенерировать два кода книги
            // Первый: число 123 > 0 — берётся как есть → "FIC_123"
            // Второй: число 0 — подставится случайное → "SCI_<случайное>"
            Console.WriteLine("Генерация кода книги");
            Console.WriteLine(library.GenerateBookCode("FIC", 123));
            Console.WriteLine(library.GenerateBookCode("SCI", 0));
            Console.WriteLine();

            // 6. Показать текущий список сотрудников
            // GetStaff() возвращает КОПИЮ, поэтому перебираем её
            Console.WriteLine("Список сотрудников");
            foreach (string staff in library.GetStaff())
            {
                Console.WriteLine(staff);
            }
            Console.WriteLine();

            // 7. Добавить нового сотрудника и показать список снова
            Console.WriteLine("Добавление нового сотрудника");
            library.AddStaff("Новиков Н.Н.");
            foreach (string staff in library.GetStaff())
            {
                Console.WriteLine(staff);
            }
            Console.WriteLine();
        }
    }
}